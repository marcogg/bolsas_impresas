<?php namespace App\SupportedApps;

class TVheadend implements Contracts\Applications {
    
    public function defaultColour()
    {
        return '#006080';
    }
    public function icon()
    {
        return 'supportedapps/tvheadend.png';
    }
   
}

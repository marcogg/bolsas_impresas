<?php namespace App\SupportedApps;
class NowShowing implements Contracts\Applications {
    public function defaultColour()
    {
        return '#690000';
    }
    public function icon()
    {
        return 'supportedapps/nowshowing.png';
    }
}

<?php namespace App\SupportedApps;

class BookStack implements Contracts\Applications {
    
    public function defaultColour()
    {
        return '#02679E';
    }
    public function icon()
    {
        return 'supportedapps/bookstack.png';
    }
   
}

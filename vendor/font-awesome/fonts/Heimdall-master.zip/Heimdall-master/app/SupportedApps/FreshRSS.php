<?php namespace App\SupportedApps;
class FreshRSS implements Contracts\Applications {
    public function defaultColour()
    {
        return '#003B73';
    }
    public function icon()
    {
        return 'supportedapps/freshrss.png';
    }
}

<?php namespace App\SupportedApps;

class Nzbhydra implements Contracts\Applications {
    public function defaultColour()
    {
        return '#53644d';
    }
    public function icon()
    {
        return 'supportedapps/nzbhydra.png';
    }
}
<?php namespace App\SupportedApps;
class WebTools implements Contracts\Applications {
    public function defaultColour()
    {
        return '#555';
    }
    public function icon()
    {
        return 'supportedapps/webtools.png';
    }
}

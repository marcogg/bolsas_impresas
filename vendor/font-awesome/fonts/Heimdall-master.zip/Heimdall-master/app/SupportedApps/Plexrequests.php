<?php namespace App\SupportedApps;

class Plexrequests implements Contracts\Applications {
    public function defaultColour()
    {
        return '#3c2d1c';
    }
    public function icon()
    {
        return 'supportedapps/plexrequests.png';
    }
}
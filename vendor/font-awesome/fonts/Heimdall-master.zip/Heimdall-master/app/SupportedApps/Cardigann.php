<?php namespace App\SupportedApps;
class Cardigann implements Contracts\Applications {
    public function defaultColour()
    {
        return '#753';
    }
    public function icon()
    {
        return 'supportedapps/cardigann.png';
    }
}

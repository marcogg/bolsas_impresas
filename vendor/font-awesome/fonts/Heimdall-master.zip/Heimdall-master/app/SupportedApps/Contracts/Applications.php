<?php namespace App\SupportedApps\Contracts;

interface Applications {

    public function defaultColour();

    public function icon();
    
}
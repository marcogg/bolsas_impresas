<?php namespace App\SupportedApps;
class Krusader implements Contracts\Applications {
    public function defaultColour()
    {
        return '#5A5';
    }
    public function icon()
    {
        return 'supportedapps/krusader.png';
    }
}

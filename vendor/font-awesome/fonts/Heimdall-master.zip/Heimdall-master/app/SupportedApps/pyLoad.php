<?php namespace App\SupportedApps;
class pyLoad implements Contracts\Applications {
    public function defaultColour()
    {
        return '#881';
    }
    public function icon()
    {
        return 'supportedapps/pyload.png';
    }
}

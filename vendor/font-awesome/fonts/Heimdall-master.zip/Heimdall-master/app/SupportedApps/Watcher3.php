<?php namespace App\SupportedApps;
class Watcher3 implements Contracts\Applications {
    public function defaultColour()
    {
        return '#500';
    }
    public function icon()
    {
        return 'supportedapps/watcher3.png';
    }
}

<?php namespace App\SupportedApps;

class Flood implements Contracts\Applications {
    public function defaultColour()
    {
        return '##00D091';
    }
    public function icon()
    {
        return 'supportedapps/Flood.png';
    }
}

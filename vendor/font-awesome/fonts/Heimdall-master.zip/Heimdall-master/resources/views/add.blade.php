                    <?php $addclass = (isset($ajax)) ? ' active' : ''; ?>
                    <section class="add-item{{ $addclass }}">
                        <a id="add-item" href="">{{ __('app.dash.pin_item') }}</a>
                    </section>
